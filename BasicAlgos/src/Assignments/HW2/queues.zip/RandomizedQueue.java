
import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
	private Item[] s;
	private int N = 0;
	
	public RandomizedQueue() {
		// construct an empty randomized queue
		s = (Item[]) new Object[1];
	}
	
	public boolean isEmpty() {
		// is the randomized queue empty?
		return N == 0;
	}
	
	public int size() {
		// return the number of items on the randomized queue
		return N;
	}
	
	public void enqueue(Item item) {
		// add the item
		if (null == item) throw new IllegalArgumentException();
		if (N == s.length) resize(2 * s.length);
		s[N++] = item;
	}
	
	public Item dequeue() {
		// remove and return a random item
		if (isEmpty()) throw new NoSuchElementException();
		int randomIndex = StdRandom.uniform(0, N);
		Item item = s[randomIndex];
		if (--N > 0) {
			for (int i = randomIndex; i < N; i++) {
				s[i] = s[i+1];
			}
		}
		if (N > 0 && N == s.length / 4) resize(s.length / 2);
		return item;
	}
	
	public Item sample()  {
		// return a random item (but do not remove it)
		if (isEmpty()) throw new NoSuchElementException();
		int randomIndex = StdRandom.uniform(0, N);
		return s[randomIndex];
	}
	
	public Iterator<Item> iterator() {
		// return an independent iterator over items in random order
		return new RandomizedQueueIterator();
	}
	
	private void resize(int capacity) {
		Item[] copy = (Item[]) new Object[capacity];
		for (int i = 0; i < N; i++)
			copy[i] = s[i];
		s = copy;
	}
	
	private class RandomizedQueueIterator implements Iterator<Item> {

		@Override
		public boolean hasNext() {
			return N > 0;
		}

		@Override
		public Item next() {
			if (!hasNext()) throw new NoSuchElementException();
			return dequeue();
		}
		
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
	
	public static void main(String[] args) {
		// unit testing (optional)
		RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
		System.out.println("IsEmpty:" + rq.isEmpty());
		System.out.println("Size:" + rq.size());
		rq.enqueue(100);
		rq.enqueue(110);
		rq.enqueue(120);
		rq.enqueue(130);
		rq.enqueue(140);
		rq.enqueue(150);
		rq.enqueue(160);
		rq.dequeue();
		System.out.println("IsEmpty:" + rq.isEmpty());
		System.out.println("Size:" + rq.size());
		// iterator
		Iterator<Integer> iter = rq.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
	}

}
